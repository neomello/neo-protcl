import{r as a,s as n,j as e,c as f,R as p}from"./sounds-Bvkg-zmS.js";function g(){const d=a.useRef(null),[c,m]=a.useState({x:0,y:0});return a.useEffect(()=>{n.playClick()},[]),a.useEffect(()=>{const r={x:0,y:0},t={x:0,y:0},o=l=>{r.x=l.clientX,r.y=l.clientY};document.addEventListener("mousemove",o);const s=()=>{t.x+=(r.x-t.x)*.15,t.y+=(r.y-t.y)*.15,m({x:t.x,y:t.y}),requestAnimationFrame(s)},i=requestAnimationFrame(s);return()=>{document.removeEventListener("mousemove",o),cancelAnimationFrame(i)}},[]),a.useEffect(()=>{const r=t=>{const o=t.target.closest('a[href^="#"]');if(o){t.preventDefault();const s=o.getAttribute("href").substring(1),i=document.getElementById(s);i&&i.scrollIntoView({behavior:"smooth"})}};return document.addEventListener("click",r),()=>document.removeEventListener("click",r)},[]),e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        html, body {
          width: 100%;
          height: 100%;
          overflow-x: hidden;
        }

        body {
          background-color: #0a0a0a;
          color: #f0f0f0;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif;
          letter-spacing: 0.5px;
          overflow: hidden;
        }

        /* Grid background */
        .grid-background {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          opacity: 0.05;
          background-image: 
            linear-gradient(0deg, #00cfff 1px, transparent 1px),
            linear-gradient(90deg, #00cfff 1px, transparent 1px);
          background-size: 50px 50px;
          z-index: 0;
        }

        /* Mouse glow effect */
        .glow {
          position: fixed;
          width: 400px;
          height: 400px;
          background: radial-gradient(circle, #00cfff 0%, transparent 70%);
          border-radius: 50%;
          filter: blur(100px);
          opacity: 0.3;
          pointer-events: none;
          mix-blend-mode: screen;
          z-index: 1;
          transform: translate(-50%, -50%);
          transition: all 0.3s ease-out;
        }

        .container {
          position: relative;
          z-index: 10;
          width: 100%;
          height: 100vh;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          padding: 2rem;
          max-width: 1280px;
          margin: 0 auto;
        }

        /* Animations */
        @keyframes fadeInDown {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fadeInScale {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        .accent {
          animation: fadeInScale 1s ease-out 0s forwards;
          margin-bottom: 3rem;
        }

        .title-section {
          animation: fadeInDown 1s ease-out 0.1s forwards;
          text-align: center;
          margin-bottom: 2rem;
        }

        .message-section {
          animation: fadeInDown 1s ease-out 0.2s forwards;
          max-width: 40rem;
          text-align: center;
          margin-bottom: 3rem;
        }

        .buttons-section {
          animation: fadeInScale 1s ease-out 0.3s forwards;
          display: flex;
          gap: 1rem;
          flex-wrap: wrap;
          justify-content: center;
        }

        /* Typography */
        .genesis-text {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.75rem;
          margin-bottom: 1.5rem;
        }

        .genesis-label {
          font-size: 0.75rem;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          color: rgba(0, 207, 255, 0.6);
          font-weight: 600;
        }

        .brain-icon {
          width: 1.5rem;
          height: 1.5rem;
          color: #00cfff;
        }

        h1 {
          font-size: clamp(3rem, 10vw, 7rem);
          font-weight: 900;
          letter-spacing: -0.02em;
          margin-bottom: 1rem;
          line-height: 1.1;
        }

        h2 {
          font-size: clamp(1.25rem, 4vw, 2rem);
          font-weight: 300;
          color: #00cfff;
          letter-spacing: 0.15em;
          text-transform: uppercase;
        }

        .message-primary {
          font-size: clamp(1.125rem, 3vw, 1.25rem);
          color: rgba(240, 240, 240, 0.8);
          line-height: 1.6;
          margin-bottom: 1rem;
          font-weight: 300;
        }

        .message-secondary {
          font-size: clamp(0.875rem, 2vw, 1rem);
          color: #00ff99;
          letter-spacing: 0.1em;
          font-weight: 500;
        }

        /* Buttons */
        .btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          padding: 0.75rem 2rem;
          border-radius: 9999px;
          font-weight: 600;
          text-decoration: none;
          cursor: pointer;
          border: none;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          font-size: 1rem;
          white-space: nowrap;
        }

        .btn-primary {
          background-color: #00cfff;
          color: #0a0a0a;
          box-shadow: 0 0 20px rgba(0, 207, 255, 0.4);
        }

        .btn-primary:hover {
          transform: scale(1.05);
          box-shadow: 0 0 30px rgba(0, 207, 255, 0.6);
        }

        .btn-primary:active {
          transform: scale(0.95);
        }

        .btn-secondary {
          border: 1px solid rgba(0, 207, 255, 0.4);
          color: #00cfff;
          background-color: transparent;
        }

        .btn-secondary:hover {
          border-color: #00cfff;
          box-shadow: 0 0 20px rgba(0, 207, 255, 0.2);
        }

        .btn-secondary:active {
          transform: scale(0.98);
        }

        .icon {
          width: 1.25rem;
          height: 1.25rem;
        }

        /* Footer */
        .footer {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          border-top: 1px solid rgba(0, 207, 255, 0.1);
          background: linear-gradient(to top, #0a0a0a, transparent);
          padding: 1.5rem;
          z-index: 10;
        }

        .footer-content {
          max-width: 1280px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          gap: 1rem;
          justify-content: space-between;
          align-items: center;
        }

        @media (min-width: 768px) {
          .footer-content {
            flex-direction: row;
          }
        }

        .footer-specs,
        .footer-links {
          display: flex;
          gap: 1.5rem;
          font-size: 0.75rem;
          color: rgba(240, 240, 240, 0.5);
          letter-spacing: 0.05em;
          text-transform: uppercase;
        }

        .footer-links a {
          color: rgba(240, 240, 240, 0.5);
          text-decoration: none;
          transition: color 0.3s ease;
        }

        .footer-links a:hover {
          color: #00cfff;
        }

        .footer-divider {
          color: rgba(240, 240, 240, 0.3);
        }

        /* Responsive */
        @media (max-width: 640px) {
          .buttons-section {
            flex-direction: column;
            gap: 0.75rem;
          }

          .btn {
            width: 100%;
          }

          .container {
            padding: 1.5rem;
            height: auto;
            min-height: 100vh;
            padding-bottom: 12rem;
          }
        }
      `}),e.jsx("div",{className:"grid-background"}),e.jsx("div",{ref:d,className:"glow",style:{left:`${c.x}px`,top:`${c.y}px`}}),e.jsxs("div",{className:"container",children:[e.jsx("div",{className:"accent",children:e.jsxs("div",{className:"genesis-text",children:[e.jsx("svg",{className:"brain-icon",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M9.59 9a6 6 0 1 1 8.82 8.82A6.5 6.5 0 0 0 12 18.5a6.5 6.5 0 0 1-6.41-9.5"})}),e.jsx("span",{className:"genesis-label",children:"Genesis Block"}),e.jsx("svg",{className:"brain-icon",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M9.59 9a6 6 0 1 1 8.82 8.82A6.5 6.5 0 0 0 12 18.5a6.5 6.5 0 0 1-6.41-9.5"})})]})}),e.jsxs("div",{className:"title-section",children:[e.jsx("h1",{children:"NΞØ HUB"}),e.jsx("h2",{children:"Intake Protocol"})]}),e.jsxs("div",{className:"message-section",children:[e.jsx("p",{className:"message-primary",children:"O primeiro mecanismo oficial para integração sem autorização central."}),e.jsx("p",{className:"message-secondary",children:"Humanos · IAs · Agentes · Contratos · Nós"})]}),e.jsxs("div",{className:"buttons-section",children:[e.jsxs("a",{href:"#protocol",className:"btn btn-primary",onClick:r=>{r.preventDefault(),n.playClick();const t=document.getElementById("protocol");t&&t.scrollIntoView({behavior:"smooth"})},children:[e.jsx("span",{children:"📋"}),e.jsx("span",{children:"Ver Especificação"})]}),e.jsxs("a",{href:"https://neoprotocol.eth.limo",target:"_blank",rel:"noopener noreferrer",className:"btn btn-secondary",onClick:()=>n.playClick(),children:[e.jsx("span",{children:"Documentação"}),e.jsx("span",{children:"↗"})]})]})]}),e.jsx("footer",{className:"footer",children:e.jsxs("div",{className:"footer-content",children:[e.jsxs("div",{className:"footer-specs",children:[e.jsx("span",{children:"v1.0"}),e.jsx("span",{className:"footer-divider",children:"|"}),e.jsx("span",{children:"Status: Ativo"})]}),e.jsxs("div",{className:"footer-links",children:[e.jsx("a",{href:"https://github.com/NEO-PROTOCOL",target:"_blank",rel:"noopener noreferrer",onClick:()=>n.playClick(),children:"GitHub"}),e.jsx("a",{href:"https://www.instagram.com/neoprotocol.eth/",target:"_blank",rel:"noopener noreferrer",onClick:()=>n.playClick(),children:"Instagram"}),e.jsx("a",{href:"https://neo-protcl.vercel.app/",target:"_blank",rel:"noopener noreferrer",onClick:()=>n.playClick(),children:"Dapp"})]})]})})]})}f.createRoot(document.getElementById("root")).render(e.jsx(p.StrictMode,{children:e.jsx(g,{})}));
